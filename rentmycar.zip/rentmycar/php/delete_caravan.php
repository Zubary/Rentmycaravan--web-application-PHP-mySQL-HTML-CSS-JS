<?php
session_start();  // Start the session to track user login

// Check if the user is logged in (if 'user_id' is set in the session)
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: ../index.php");
    exit(); // Ensure no further code is executed
}

// Include database connection
require_once '../php/db_connect.php';  // Adjust the path if needed

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $vehicle_id = $_GET['id'];

    // Prepare the delete query
    $delete_query = "DELETE FROM vehicle_details WHERE vehicle_id = ? AND user_id = ?";
    
    if ($stmt = $conn->prepare($delete_query)) {
        // Bind parameters and execute the delete query
        $stmt->bind_param("ii", $vehicle_id, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            // Redirect back to the dashboard after deletion
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        
        $stmt->close();
    } else {
        echo "Error preparing the delete query.";
    }
} else {
    echo "No vehicle ID provided.";
}

// Close the database connection
$conn->close();
?>
