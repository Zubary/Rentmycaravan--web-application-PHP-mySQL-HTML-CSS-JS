<?php
session_start();  // Start the session to track user login

// Include database connection
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Validate form fields
    if (empty($username) || empty($password)) {
        $_SESSION['error_message'] = "Please enter both username and password.";
        header("Location: ../index.php");  // Redirect back to the login page
        exit();
    }

    // Query to check if the username exists in the database
    $query = "SELECT * FROM users WHERE username = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        // If username exists, check the password
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $stored_password_hash = $user['PASSWORD'];  // MD5 hashed password stored in the database

            // Hash the entered password using MD5 to compare with the stored hash
            $hashed_password_input = md5($password);

            // Compare the MD5 hash of the input password with the stored hash
            if ($hashed_password_input === $stored_password_hash) {
                // Password is correct, set up the session and redirect to dashboard
                $_SESSION['user_id'] = $user['user_id'];  // Store user ID in session
                $_SESSION['username'] = $user['username'];  // Store username in session
                header("Location: dashboard.php");  // Redirect to the dashboard
                exit();
            } else {
                $_SESSION['error_message'] = "Incorrect password!";
                header("Location: ../index.php");  // Redirect back to the login page
                exit();
            }
        } else {
            $_SESSION['error_message'] = "No user found with that username!";
            header("Location: ../index.php");  // Redirect back to the login page
            exit();
        }
        $stmt->close();
    }

    $conn->close();
}
?>
