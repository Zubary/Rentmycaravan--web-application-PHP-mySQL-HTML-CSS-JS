<?php
// Include the database connection
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $title = trim($_POST['title']);
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $gender = trim($_POST['gender']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];
    $email = trim($_POST['email']);
    $telephone = trim($_POST['telephone']);
    $adress1 = trim($_POST['adress1']);
    $adress2 = trim($_POST['adress2']);
    $adress3 = trim($_POST['adress3']);
    $postcode = trim($_POST['postcode']);
    $description = trim($_POST['description']);
    $profile_url = trim($_POST['profile_url']);

    // Handle file upload for profile picture
    $profile_blob = NULL;
    if (isset($_FILES['profile_blob']) && $_FILES['profile_blob']['error'] == UPLOAD_ERR_OK) {
        // Get file details
        $file_tmp = $_FILES['profile_blob']['tmp_name'];
        $file_name = $_FILES['profile_blob']['name'];
        $file_data = file_get_contents($file_tmp);

        // Check if the file is a valid image
        $image_info = getimagesize($file_tmp);
        if ($image_info !== false) {
            $profile_blob = $file_data;
        }
    }

    // Validate form fields
    if (empty($username) || empty($password) || empty($confirm_password) || empty($email)) {
        echo "All required fields must be filled!";
        exit;
    }

    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
        exit;
    }

    // Check if username already exists
    $query = "SELECT * FROM users WHERE username = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            echo "Username already taken!";
            exit;
        }
        $stmt->close();
    }

    // Hash the password
    $hashed_password = md5($password);

    // Insert the user into the database
    $insert_query = "INSERT INTO users (username, password, title, first_name, last_name, gender, adress1, adress2, adress3, postcode, description, email, telephone, profile_blob, profile_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    if ($stmt = $conn->prepare($insert_query)) {
        $stmt->bind_param("ssssssssssssbss", $username, $hashed_password, $title, $first_name, $last_name, $gender, $adress1, $adress2, $adress3, $postcode, $description, $email, $telephone, $profile_blob, $profile_url);

        if ($stmt->execute()) {
            header("Location: ../index.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    // Close database connection
    $conn->close();
}
?>
