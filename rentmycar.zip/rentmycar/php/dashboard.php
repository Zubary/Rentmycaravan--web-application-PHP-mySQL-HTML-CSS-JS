<?php
session_start();  // Start the session to track user login

// Check if the user is logged in (if 'user_id' is set in the session)
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: ../index.php");
    exit(); // Ensure no further code is executed
}

// Include database connection
require_once '../php/db_connect.php';  // Adjust the path if needed

// Get the logged-in user's ID from the session
$user_id = $_SESSION['user_id'];

// Query to fetch the user's caravans
$query = "SELECT * FROM vehicle_details WHERE user_id = ?";
if ($stmt = $conn->prepare($query)) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $caravans = [];
    
    // Fetch all caravans for the logged-in user
    while ($row = $result->fetch_assoc()) {
        $caravans[] = $row;
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - RentMyCaravan.io</title>
    <link rel="stylesheet" href="../css/dashboard.css">
</head>

<body>
    <header>
        <h1>Welcome to Your Dashboard, <span id="username"><?php echo $_SESSION['username']; ?></span></h1>
        <nav>
            <ul>
                <li><a href="add_caravan.php">Add Caravan</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <section class="user-info">
        <h3>Your Caravans</h3>
        <div class="caravan-list">
            <?php if (empty($caravans)): ?>
                <p>No caravans found. Add a new caravan!</p>
            <?php else: ?>
                <?php foreach ($caravans as $caravan): ?>
                    <div class="caravan-card">
                        <div class="caravan-image">
                            <?php if (!empty($caravan['image_url'])): ?>
                                <img src="../<?php echo $caravan['image_url']; ?>" alt="Caravan Image">
                            <?php endif; ?>
                        </div>
                        <div class="caravan-details">
                            <h3><?php echo $caravan['vehicle_make'] . ' ' . $caravan['vehicle_model']; ?></h3>
                            <p><strong>Body Type:</strong> <?php echo $caravan['vehicle_bodytype']; ?></p>
                            <p><strong>Fuel Type:</strong> <?php echo $caravan['fuel_type']; ?></p>
                            <p><strong>Mileage:</strong> <?php echo $caravan['mileage']; ?></p>
                            <p><strong>Location:</strong> <?php echo $caravan['location']; ?></p>
                            <p><strong>Year:</strong> <?php echo $caravan['year']; ?></p>
                            <p><strong>Doors:</strong> <?php echo $caravan['num_doors']; ?></p>
                            <p>
                                <a href="edit_caravan.php?id=<?php echo $caravan['vehicle_id']; ?>" class="edit-details">Edit Details</a>
                                <a href="#" class="delete-details" data-vehicle-id="<?php echo $caravan['vehicle_id']; ?>">Delete</a>
                            </p>

                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>

    <!-- Custom Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <h3>Are you sure you want to delete this caravan?</h3>
            <p>This action cannot be undone.</p>
            <button id="confirmDeleteBtn" class="confirm-btn">Delete</button>
            <button id="cancelDeleteBtn" class="cancel-btn">Cancel</button>
        </div>
    </div>

</body>

</html>
<script src="../js/dashboard.js"></script>

