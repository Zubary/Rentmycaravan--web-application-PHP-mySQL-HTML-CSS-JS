<?php
// Database connection details
$servername = "localhost";
$username = "root";  // Change this to your DB username
$password = "1234";  // Change this to your DB password
$dbname = "rentmycar";  // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
