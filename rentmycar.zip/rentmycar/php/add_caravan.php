<?php
session_start();  // Start session to track user login

// Include database connection
require_once 'db_connect.php';

// Check if the user is logged in (if 'user_id' is set in the session)
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");  // Redirect to login if not logged in
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $vehicle_make = trim($_POST['vehicle_make']);
    $vehicle_model = trim($_POST['vehicle_model']);
    $vehicle_bodytype = trim($_POST['vehicle_bodytype']);
    $fuel_type = trim($_POST['fuel_type']);
    $mileage = trim($_POST['mileage']);
    $location = trim($_POST['location']);
    $year = trim($_POST['year']);
    $num_doors = trim($_POST['num_doors']);
    $user_id = $_SESSION['user_id'];  // Get the logged-in user's ID

    // Handle file upload for the vehicle image
    $image_url = NULL;
    if (isset($_FILES['image_url']) && $_FILES['image_url']['error'] == UPLOAD_ERR_OK) {
        $image_tmp = $_FILES['image_url']['tmp_name'];
        $image_name = $_FILES['image_url']['name'];
        $image_url = 'uploads/' . $image_name; // Store the file path

        // Move the uploaded image to the 'uploads' folder
        move_uploaded_file($image_tmp, '../uploads/' . $image_name);
    }

    // Handle file upload for the vehicle video (optional)
    $video_path = NULL;  // Renamed variable to avoid overwriting
    if (isset($_FILES['video_url']) && $_FILES['video_url']['error'] == UPLOAD_ERR_OK) {
        $video_tmp = $_FILES['video_url']['tmp_name'];
        $video_name = $_FILES['video_url']['name'];
        $video_path = 'uploads/' . $video_name; // Store the file path

        // Move the uploaded video to the 'uploads' folder
        move_uploaded_file($video_tmp, '../uploads/' . $video_name);
    }

    // Validate form fields
    if (empty($vehicle_make) || empty($vehicle_model) || empty($vehicle_bodytype) || empty($fuel_type) || empty($mileage) || empty($location) || empty($year) || empty($num_doors)) {
        echo "All required fields must be filled!";
        exit;
    }

    // Insert the vehicle (caravan) into the database
    $insert_query = "INSERT INTO vehicle_details (user_id, vehicle_make, vehicle_model, vehicle_bodytype, fuel_type, mileage, location, year, num_doors, video_url, image_url) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    if ($stmt = $conn->prepare($insert_query)) {
        $stmt->bind_param("issssssisss", $user_id, $vehicle_make, $vehicle_model, $vehicle_bodytype, $fuel_type, $mileage, $location, $year, $num_doors, $video_path, $image_url);

        if ($stmt->execute()) {
            echo "Caravan added successfully!";
            header("Location: dashboard.php");  // Redirect to the dashboard after success
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Caravan - RentMyCaravan.io</title>
    <link rel="stylesheet" href="../css/add_caravan.css">
</head>

<body>

    <section class="add-caravan-section">
        <h2>Add Your Caravan</h2>
        <p>Fill in the details below. Please provide all the required information about your caravan.</p>
        <form method="POST" action="add_caravan.php" enctype="multipart/form-data">
            <label for="vehicle_make">Vehicle Make:</label>
            <input type="text" id="vehicle_make" name="vehicle_make" required>

            <label for="vehicle_model">Vehicle Model:</label>
            <input type="text" id="vehicle_model" name="vehicle_model" required>

            <label for="vehicle_bodytype">Vehicle Body Type:</label>
            <select id="vehicle_bodytype" name="vehicle_bodytype" required>
                <option value="Van">Van</option>
                <option value="SUV">SUV</option>
                <option value="Truck">Truck</option>
                <option value="Motorhome">Motorhome</option>
            </select>

            <label for="fuel_type">Fuel Type:</label>
            <select id="fuel_type" name="fuel_type" required>
                <option value="Diesel">Diesel</option>
                <option value="Petrol">Petrol</option>
                <option value="Electric">Electric</option>
                <option value="Hybrid">Hybrid</option>
            </select>

            <label for="mileage">Mileage:</label>
            <input type="text" id="mileage" name="mileage" required>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>

            <label for="year">Year:</label>
            <input type="text" id="year" name="year" required>

            <label for="num_doors">Number of Doors:</label>
            <select id="num_doors" name="num_doors" required>
                <option value="2">2</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>

            <label for="video_url">Video URL (Optional):</label>
            <input type="file" id="video_url" name="video_url" accept="video/*">

            <label for="image_url">Caravan Image:</label>
            <input type="file" id="image_url" name="image_url" accept="image/*" required>

            <button type="submit">Add Caravan</button>
        </form>
    </section>

    <footer>
        <p>&copy; 2025 RentMyCaravan.io</p>
    </footer>
</body>

</html>
