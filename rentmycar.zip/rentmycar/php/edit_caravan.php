<?php
session_start();  // Start the session to track user login

// Check if the user is logged in (if 'user_id' is set in the session)
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: ../index.php");
    exit(); // Ensure no further code is executed
}

// Include database connection
require_once '../php/db_connect.php';  // Adjust the path if needed

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $vehicle_id = $_GET['id'];
    
    // Query to fetch the caravan details by vehicle_id
    $query = "SELECT * FROM vehicle_details WHERE vehicle_id = ? AND user_id = ?";
    
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("ii", $vehicle_id, $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result();

        // If caravan is found
        if ($row = $result->fetch_assoc()) {
            $vehicle_make = $row['vehicle_make'];
            $vehicle_model = $row['vehicle_model'];
            $vehicle_bodytype = $row['vehicle_bodytype'];
            $fuel_type = $row['fuel_type'];
            $mileage = $row['mileage'];
            $location = $row['location'];
            $year = $row['year'];
            $num_doors = $row['num_doors'];
            $image_url = $row['image_url'];
            $video_url = $row['video_url'];
        } else {
            echo "Caravan not found!";
            exit();
        }
        $stmt->close();
    } else {
        echo "Error fetching caravan details.";
        exit();
    }
} else {
    echo "No vehicle ID provided.";
    exit();
}

// Handle the form submission to update the caravan details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $vehicle_make = trim($_POST['vehicle_make']);
    $vehicle_model = trim($_POST['vehicle_model']);
    $vehicle_bodytype = trim($_POST['vehicle_bodytype']);
    $fuel_type = trim($_POST['fuel_type']);
    $mileage = trim($_POST['mileage']);
    $location = trim($_POST['location']);
    $year = trim($_POST['year']);
    $num_doors = trim($_POST['num_doors']);
    
    // Handle file upload for the caravan image (if a new image is uploaded)
    $image_url_new = $image_url;  // Default to the existing image
    if (isset($_FILES['image_url']) && $_FILES['image_url']['error'] == UPLOAD_ERR_OK) {
        $image_tmp = $_FILES['image_url']['tmp_name'];
        $image_name = $_FILES['image_url']['name'];
        $image_url_new = 'uploads/' . $image_name;  // Store the new image path
        move_uploaded_file($image_tmp, '../uploads/' . $image_name);
    }

    // Handle file upload for the video (optional)
    $video_url_new = $video_url;  // Default to the existing video URL
    if (isset($_FILES['video_url']) && $_FILES['video_url']['error'] == UPLOAD_ERR_OK) {
        $video_tmp = $_FILES['video_url']['tmp_name'];
        $video_name = $_FILES['video_url']['name'];
        $video_url_new = 'uploads/' . $video_name;  // Store the new video path
        move_uploaded_file($video_tmp, '../uploads/' . $video_name);
    }

    // Update the vehicle details in the database
    $update_query = "UPDATE vehicle_details SET vehicle_make = ?, vehicle_model = ?, vehicle_bodytype = ?, fuel_type = ?, mileage = ?, location = ?, year = ?, num_doors = ?, image_url = ?, video_url = ? WHERE vehicle_id = ? AND user_id = ?";
    
    if ($stmt = $conn->prepare($update_query)) {
        $stmt->bind_param("ssssssssssii", $vehicle_make, $vehicle_model, $vehicle_bodytype, $fuel_type, $mileage, $location, $year, $num_doors, $image_url_new, $video_url_new, $vehicle_id, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            // Redirect back to the dashboard after successful update
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Error updating the caravan details: " . $stmt->error;
        }
        
        $stmt->close();
    } else {
        echo "Error preparing the update query.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Caravan - RentMyCaravan.io</title>
    <link rel="stylesheet" href="../css/add_caravan.css">
</head>
<body>
    <section class="add-caravan-section">
        <h2>Edit Your Caravan</h2>
        <!-- Edit Caravan Form -->
        <form method="POST" action="edit_caravan.php?id=<?php echo $vehicle_id; ?>" enctype="multipart/form-data">
            <label for="vehicle_make">Vehicle Make:</label>
            <input type="text" id="vehicle_make" name="vehicle_make" value="<?php echo $vehicle_make; ?>" required>

            <label for="vehicle_model">Vehicle Model:</label>
            <input type="text" id="vehicle_model" name="vehicle_model" value="<?php echo $vehicle_model; ?>" required>

            <label for="vehicle_bodytype">Vehicle Body Type:</label>
            <select id="vehicle_bodytype" name="vehicle_bodytype" required>
                <option value="Van" <?php echo ($vehicle_bodytype == 'Van' ? 'selected' : ''); ?>>Van</option>
                <option value="SUV" <?php echo ($vehicle_bodytype == 'SUV' ? 'selected' : ''); ?>>SUV</option>
                <option value="Truck" <?php echo ($vehicle_bodytype == 'Truck' ? 'selected' : ''); ?>>Truck</option>
                <option value="Motorhome" <?php echo ($vehicle_bodytype == 'Motorhome' ? 'selected' : ''); ?>>Motorhome</option>
            </select>

            <label for="fuel_type">Fuel Type:</label>
            <select id="fuel_type" name="fuel_type" required>
                <option value="Diesel" <?php echo ($fuel_type == 'Diesel' ? 'selected' : ''); ?>>Diesel</option>
                <option value="Petrol" <?php echo ($fuel_type == 'Petrol' ? 'selected' : ''); ?>>Petrol</option>
                <option value="Electric" <?php echo ($fuel_type == 'Electric' ? 'selected' : ''); ?>>Electric</option>
                <option value="Hybrid" <?php echo ($fuel_type == 'Hybrid' ? 'selected' : ''); ?>>Hybrid</option>
            </select>

            <label for="mileage">Mileage:</label>
            <input type="text" id="mileage" name="mileage" value="<?php echo $mileage; ?>" required>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" value="<?php echo $location; ?>" required>

            <label for="year">Year:</label>
            <input type="text" id="year" name="year" value="<?php echo $year; ?>" required>

            <label for="num_doors">Number of Doors:</label>
            <select id="num_doors" name="num_doors" required>
                <option value="2" <?php echo ($num_doors == '2' ? 'selected' : ''); ?>>2</option>
                <option value="4" <?php echo ($num_doors == '4' ? 'selected' : ''); ?>>4</option>
                <option value="5" <?php echo ($num_doors == '5' ? 'selected' : ''); ?>>5</option>
            </select>

            <label for="image_url">Caravan Image (Optional):</label>
            <input type="file" id="image_url" name="image_url" accept="image/*">

            <!-- Display current image if available -->
            <label for="image_url">Caravan Image :</label>
            <?php if (!empty($image_url)): ?>
                <div class="current-image">
                  
                    <img src="../<?php echo $image_url; ?>" alt="Current Caravan Image" class="current-image-preview">
                </div>
            <?php endif; ?>

            <label for="video_url">Caravan Video (Optional):</label>
            <input type="file" id="video_url" name="video_url" accept="video/*">

            <br>

            <button type="submit">Save Changes</button>
        </form>

    </section>
</body>
</html>
