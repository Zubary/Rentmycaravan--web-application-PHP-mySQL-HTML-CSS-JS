<?php
// Start the session
session_start();

// Include database connection file
require_once 'php/db_connect.php';  // Adjust the path as needed

// Query to fetch the latest 5 caravans (you can adjust the limit as needed)
$query = "SELECT * FROM vehicle_details ORDER BY vehicle_id DESC LIMIT 5";  // Adjust the table and column names as per your database structure
$result = $conn->query($query);

// Fetch all rows into an array
$caravans = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $caravans[] = $row;
    }
} else {
    $caravans = [];
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to RentMyCaravan.io</title>
  <link rel="stylesheet" href="css/style.css">
  <script src="js/script.js" defer></script>
</head>

<body>
  <!-- Header Section -->
  <header>
    <h1>Welcome to RentMyCaravan.io</h1>
    <p>Find, rent, and share caravans with local businesses and residents.</p>
  </header>

  <!-- Login Form -->
  <section class="login-section">
    <h2>Login</h2>
    <form id="login-form" method="POST" action="php/login_user.php">
      <label for="username">Username:</label>
      <input type="text" id="username" name="username" required placeholder="Enter your username">

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required placeholder="Enter your password">

      <button type="submit">Login</button>
    </form>
    <p>New here? <a href="register.html">Register</a></p>

    <!-- Display error message if it exists -->
    <?php
    if (isset($_SESSION['error_message'])) {
        echo "<p style='color: red;'>" . $_SESSION['error_message'] . "</p>";
        unset($_SESSION['error_message']);  // Clear the error message after displaying it
    }
    ?>
  </section>

    <!-- Latest Caravans Section -->
    <section class="latest-caravans">
    <h2>Latest Caravans</h2>
    <div class="caravan-list">
      <?php if (empty($caravans)): ?>
        <p>No caravans available at the moment.</p>
      <?php else: ?>
        <?php foreach ($caravans as $caravan): ?>
          <div class="caravan-card">
            <!-- Caravan Image -->
            <?php if (!empty($caravan['image_url'])): ?>
              <img src="<?php echo $caravan['image_url']; ?>" alt="Caravan Image" class="caravan-image">
            <?php else: ?>
              <img src="images/default-image.jpg" alt="Default Image" class="caravan-image"> <!-- Default image if no image is found -->
            <?php endif; ?>
            
            <div class="caravan-info">
              <h3><?php echo htmlspecialchars($caravan['vehicle_make']) . ' ' . htmlspecialchars($caravan['vehicle_model']); ?></h3>
              <p><strong>Type:</strong> <?php echo htmlspecialchars($caravan['vehicle_bodytype']); ?> | <strong>Fuel:</strong> <?php echo htmlspecialchars($caravan['fuel_type']); ?></p>
              <p><strong>Location:</strong> <?php echo htmlspecialchars($caravan['location']); ?></p>
              <p><?php echo substr(htmlspecialchars($caravan['mileage']), 0, 100) . '...'; ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </section>

  <!-- Footer Section -->
  <footer>
    <p>&copy; 2025 RentMyCaravan.io</p>
  </footer>
</body>

</html>