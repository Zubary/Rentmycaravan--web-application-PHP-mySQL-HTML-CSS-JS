// Get modal element
var modal = document.getElementById("deleteModal");

// Get open modal button (the delete link)
var deleteLinks = document.querySelectorAll(".delete-details");

// Get close button
var closeBtn = document.querySelector(".close-btn");

// Get the confirm delete button
var confirmDeleteBtn = document.getElementById("confirmDeleteBtn");

// Get the cancel delete button
var cancelDeleteBtn = document.getElementById("cancelDeleteBtn");

// The variable to store the vehicle ID to be deleted
var deleteVehicleId = null;

// Open the modal when delete link is clicked
deleteLinks.forEach(function (link) {
  link.addEventListener("click", function (event) {
    event.preventDefault(); // Prevent default link behavior
    deleteVehicleId = this.getAttribute("data-vehicle-id"); // Get the vehicle id from data attribute
    modal.style.display = "block"; // Show the modal
  });
});

// Close the modal
closeBtn.onclick = function () {
  modal.style.display = "none";
};

// Close the modal when clicking outside of it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

// Cancel the deletion
cancelDeleteBtn.onclick = function () {
  modal.style.display = "none"; // Close the modal
};

// Confirm deletion
confirmDeleteBtn.onclick = function () {
  // Redirect to delete_caravan.php with the vehicle id
  window.location.href = "../php/delete_caravan.php?id=" + deleteVehicleId;
};
