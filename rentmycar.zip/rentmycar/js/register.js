function showAlert(message) {
  const alertBox = document.getElementById("alert-box");
  alertBox.textContent = message;
  alertBox.classList.add("show");
  setTimeout(() => {
    alertBox.classList.remove("show");
  }, 4000); // Hide the alert after 4 seconds
}

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registration-form");

  form.addEventListener("submit", (event) => {
    // Capture form data
    const title = document.getElementById("title").value;
    const firstName = document.getElementById("first_name").value.trim();
    const lastName = document.getElementById("last_name").value.trim();
    const gender = document.getElementById("gender").value;
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    const email = document.getElementById("email").value.trim();
    const telephone = document.getElementById("telephone").value.trim();
    const adress1 = document.getElementById("adress1").value.trim();
    const postcode = document.getElementById("postcode").value.trim();

    // Required fields validation
    if (
      !title ||
      !firstName ||
      !lastName ||
      !username ||
      !password ||
      !confirmPassword ||
      !email ||
      !telephone ||
      !adress1 ||
      !postcode
    ) {
      showAlert("All required fields must be filled out!");
      event.preventDefault(); // Prevent form submission
      return;
    }

    // Password match check
    if (password !== confirmPassword) {
      showAlert("Passwords do not match!");
      event.preventDefault();
      return;
    }

    // Email format validation
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email.match(emailPattern)) {
      showAlert("Please enter a valid email address!");
      event.preventDefault();
      return;
    }

    // Telephone format validation (example: (123) 456-7890 or 123-456-7890)
    const telephonePattern = /^[0-9]{3}[-\s]?[0-9]{3}[-\s]?[0-9]{4}$/;
    if (!telephone.match(telephonePattern)) {
      showAlert("Please enter a valid telephone number!");
      event.preventDefault();
      return;
    }

    // Character limit validation for fields
    if (username.length > 20) {
      showAlert("Username must be 20 characters or less.");
      event.preventDefault();
      return;
    }

    if (firstName.length > 50 || lastName.length > 50) {
      showAlert("First name and Last name must be 50 characters or less.");
      event.preventDefault();
      return;
    }

    if (postcode.length > 10) {
      showAlert("Postcode must be 10 characters or less.");
      event.preventDefault();
      return;
    }

    if (password.length < 6 || password.length > 10) {
      showAlert("Password must be between 6 and 10 characters long.");
      event.preventDefault();
      return;
    }
  });
});
